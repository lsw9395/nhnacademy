package product.cup;

public class PlasticCup extends Cup{

    @Override
    public String getType() {
        return "플라스틱컵";
    }
    
}
