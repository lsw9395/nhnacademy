package product.cup;

public class PaperCup extends Cup{

    @Override
    public String getType() {
        return "종이컵";
    }
}
