package product.beverage;

public class Americano extends BaseBeverage{


    public Americano(){
        super("아메리카노", 1500, true);
    }


    @Override
    public void setState(boolean state){
        super.setState(state);
        super.setPrice(super.getPrice()+500);
        super.setName("아이스아메리카노");
    }
    @Override
    void extract() {
        System.out.println("에스프레소를 추출중입니다.");
    }


    @Override
    void enterWater() {
        if(super.isState()){
            System.out.println("따뜻한 물을 붓습니다.");
        } else {
            System.out.println("차가운 물을 붓습니다.");
        }
    }

    @Override
    void topping() {
      // TODO document why this method is empty
    }

}
