package product.beverage;

import framework.Beverage;

public abstract class BaseBeverage implements Beverage{
    private String name;
    private int price;
    private boolean state;

    protected BaseBeverage(String name, int price, boolean state){
        this.name = name;
        this.price = price;
        this.state = state;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getPrice() {
        return price;
    }

    @Override
    public boolean isState() {
        return state;
    }

    @Override
    public void setState(boolean state) {
        this.state = state;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void setPrice(int price) {
        this.price = price;
    }
    @Override
    public String toString() {
        return "{" +
                "name='" + getName() + '\'' +
                ", price=" + getPrice() +
                '}';
    }
    @Override
    public void make() {
        extract();
        enterWater();
        topping();
    }
    abstract void extract();
    abstract void enterWater();
    abstract void topping();
}
