package product.beverage;

public class CafeLatte extends BaseBeverage{
    public CafeLatte(){
        super("카페라떼", 2000, true);
    }


    @Override
    public void setState(boolean state){
        super.setState(state);
        super.setPrice(super.getPrice()+500);
        super.setName("아이스카페라떼");
    }

    @Override
    public String toString() {
        return "{" +
                "name='" + super.getName() + '\'' +
                ", price=" + super.getPrice() +
                '}';
    }


    @Override
    void extract() {
        System.out.println("에스프레소를 추출중입니다.");
    }


    @Override
    void enterWater() {
        if(isState()){
            System.out.println("따뜻한 우유를 붓습니다.");
        } else {
            System.out.println("차가운 우유를 붓습니다.");
        }
    }


    @Override
    void topping() {
        System.out.println("커피 파우더를 뿌립니다.");
    }
}
