package product.beverage;

public class PeachIceTea extends BaseBeverage{
    public PeachIceTea(){
        super("복숭아 아이스티", 2000, true);
    }
    @Override
    void extract() {
        System.out.println("복숭아 원액을 추출중입니다.");
    }

    @Override
    void enterWater() {
        System.out.println("차가운 물을 붓습니다.");
    }

    @Override
    void topping() {
        System.out.println("레몬 슬라이스를 올립니다.");
    }

}
