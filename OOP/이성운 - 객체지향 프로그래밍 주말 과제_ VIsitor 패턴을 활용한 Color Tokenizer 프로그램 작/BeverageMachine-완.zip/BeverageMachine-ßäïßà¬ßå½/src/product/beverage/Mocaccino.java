package product.beverage;

public class Mocaccino extends BaseBeverage{
    public Mocaccino(){
        super("모카치노",2500,true);
    }

    @Override
    void extract() {
        System.out.println("에스프레소를 추출중입니다.");
        System.out.println("초코 시럽을 추출중입니다.");
    }

    @Override
    void enterWater() {
        System.out.println("뜨거운 우유와 거품을 붓습니다.");
    }

    @Override
    void topping() {
        System.out.println("시나몬 파우더나 초코 파우더를 뿌립니다.");
    }
}