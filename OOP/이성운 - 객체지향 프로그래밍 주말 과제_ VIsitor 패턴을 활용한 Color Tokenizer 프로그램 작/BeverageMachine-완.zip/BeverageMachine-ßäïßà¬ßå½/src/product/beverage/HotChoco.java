package product.beverage;

public class HotChoco extends BaseBeverage{
    public HotChoco(){
        super("핫초코", 2000, true);
    }
    @Override
    public void setState(boolean state){
        super.setState(state);
        super.setPrice(super.getPrice()+500);
        super.setName("아이스초코");
    }
    @Override
    void extract() {
        System.out.println("초코 원액을 추출중입니다.");
    }

    @Override
    void enterWater() {
        if(isState()){
            System.out.println("따뜻한 물을 붓습니다.");
        } else {
            System.out.println("차가운 물을 붓습니다.");
        }
    }

    @Override
    void topping() {
        System.out.println("초코가루와 초콜릿을 살짝 올립니다.");
    }

}
