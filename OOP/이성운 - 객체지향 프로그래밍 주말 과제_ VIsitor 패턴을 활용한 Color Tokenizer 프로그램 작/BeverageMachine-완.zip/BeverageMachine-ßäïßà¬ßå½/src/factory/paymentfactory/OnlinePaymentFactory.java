package factory.paymentfactory;

import framework.Payment;
import framework.PaymentFactory;
import pay.OnlinePayment;

public class OnlinePaymentFactory extends PaymentFactory{

    @Override
    public Payment createPayment() {
        System.out.println("온라인 결제");
        return new OnlinePayment();
    }

}
