package factory.paymentfactory;

import framework.Payment;
import framework.PaymentFactory;
import pay.CardPayment;

public class CardPaymentFactory extends PaymentFactory{

    @Override
    public Payment createPayment() {
        System.out.println("카드 결제");
        return new CardPayment();
    }

}
