package factory.machine;

import factory.beveragefactory.AmericanoFactory;
import factory.beveragefactory.CafeLatteFactory;
import factory.beveragefactory.HotChocoFactory;
import factory.beveragefactory.MocaccinoFactory;
import factory.beveragefactory.PeachIceTeaFactory;
import factory.paymentfactory.CardPaymentFactory;
import factory.paymentfactory.CashPaymentFactory;
import factory.paymentfactory.OnlinePaymentFactory;
import framework.Beverage;
import framework.BeverageFactory;
import framework.Payment;
import framework.PaymentFactory;
import product.cup.Cup;

public class Machine {
    private Payment payment;
    private Beverage beverage;
    private CupMachine cupMachine;
    private IceMachine iceMachine;

    public void selectBeverage(int m){
        BeverageFactory beverageFactory;
        switch(m){
            case 0: beverageFactory = new AmericanoFactory(); break;
            case 1: beverageFactory = new CafeLatteFactory();break;
            case 2: beverageFactory = new HotChocoFactory();break;
            case 3: beverageFactory = new MocaccinoFactory();break;
            case 4: beverageFactory = new AmericanoFactory(); beverageFactory.isState(false); break;
            case 5: beverageFactory = new CafeLatteFactory(); beverageFactory.isState(false); break;
            case 6: beverageFactory = new HotChocoFactory(); beverageFactory.isState(false); break;
            case 7: beverageFactory = new PeachIceTeaFactory(); beverageFactory.isState(false); break;
            default: throw new IllegalArgumentException();
        }
        beverage = beverageFactory.orderBeverage();
        System.out.println("선택 메뉴: "+beverage.toString());
    }

    public void selectPayment(int p){
        PaymentFactory paymentFactory;
        switch(p){
            case 0: paymentFactory = new CardPaymentFactory(); break;
            case 1: paymentFactory = new CashPaymentFactory(); break;
            case 2: paymentFactory = new OnlinePaymentFactory(); break;
            default : throw new IllegalArgumentException();
        }
        payment = paymentFactory.pay();
    }

    public Machine(){
        this.cupMachine = new CupMachine();
        this.iceMachine = new IceMachine();
    }

    private boolean paying(){
        if(payment.pay(beverage.getPrice())){
            System.out.println(payment.getClass().getSimpleName()+" 결제 성공");
            return true;
        } else {
            System.out.println(payment.getClass().getSimpleName()+"결제 실패");
            return false;
        }
    }


    public void makeBeverage(){
        if(!paying()){
            return;
        }
        Cup cup = cupMachine.takeCup(beverage);

        System.out.println(cup.getType()+"을 얻었습니다.");

        iceMachine.addIce(cup);

        beverage.make();

        System.out.println("완성되었습니다. 가져가세요!");
    }


}
