package framework;

public abstract class PaymentFactory {

    public Payment pay(){
        return createPayment();
    }
    public abstract Payment createPayment();
}
