package framework;

public interface Beverage {
    String getName();
    int getPrice();
    boolean isState();
    void setName(String name);
    void setPrice(int price);
    void setState(boolean state);
    void make();
}
