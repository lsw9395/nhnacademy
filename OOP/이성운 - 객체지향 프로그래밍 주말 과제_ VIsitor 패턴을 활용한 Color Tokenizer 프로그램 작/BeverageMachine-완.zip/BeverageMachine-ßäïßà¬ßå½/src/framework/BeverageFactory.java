package framework;

public abstract class BeverageFactory {
    Beverage orderBeverage;
    boolean state = true;
    public Beverage orderBeverage(){
        orderBeverage = createBeverage();
        if(!state){
            orderBeverage.setState(false);
        }
        return orderBeverage;
    }
    public void isState(boolean state){
        this.state = state;
    }
    public abstract Beverage createBeverage();

}
