package framework;

public interface Payment {
    boolean pay(int price);
}
