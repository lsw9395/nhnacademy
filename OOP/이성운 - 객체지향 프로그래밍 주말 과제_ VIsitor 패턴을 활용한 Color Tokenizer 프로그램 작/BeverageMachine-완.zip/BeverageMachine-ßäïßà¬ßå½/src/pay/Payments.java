package pay;

public enum Payments{
    CARD,CASH,ONLINE;
}