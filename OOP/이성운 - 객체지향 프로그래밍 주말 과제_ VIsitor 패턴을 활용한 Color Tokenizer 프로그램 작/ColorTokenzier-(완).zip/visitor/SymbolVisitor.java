package visitor;

import token.Token;

public class SymbolVisitor implements IVisitor{

    @Override
    public String visit(Token token) {
        String symbol = "<font color=\"red\">"+token.getData()+"</font>";
        if(token.getData().equals(";")||token.getData().equals("}")||token.getData().equals("{")){
            symbol = symbol+"</div>\n<div>";
        }
        return symbol;
    }

}
