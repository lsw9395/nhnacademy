package visitor;

import token.Token;

public interface IVisitor{
    public String visit(Token token);
}