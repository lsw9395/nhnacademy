package visitor;
import token.Token;

public class VariableVisitor implements IVisitor{

    @Override
    public String visit(Token token) {
        return token.getData();
    }
    
}
