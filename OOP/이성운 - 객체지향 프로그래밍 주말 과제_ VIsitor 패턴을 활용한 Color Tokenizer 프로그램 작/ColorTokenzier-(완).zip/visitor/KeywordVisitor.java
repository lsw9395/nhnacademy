package visitor;

import token.Token;

public class KeywordVisitor implements IVisitor{


    @Override
    public String visit(Token token) {
        String keyword = "<font color=\"blue\"><b>"+token.getData()+"</b></font>";
        return keyword;
    }

}
