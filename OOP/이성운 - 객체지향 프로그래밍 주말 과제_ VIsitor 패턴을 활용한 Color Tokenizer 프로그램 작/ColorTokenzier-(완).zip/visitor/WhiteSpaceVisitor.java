package visitor;

import token.Token;

public class WhiteSpaceVisitor implements IVisitor{

    @Override
    public String visit(Token token) {
        return "&nbsp;";
    }

}
