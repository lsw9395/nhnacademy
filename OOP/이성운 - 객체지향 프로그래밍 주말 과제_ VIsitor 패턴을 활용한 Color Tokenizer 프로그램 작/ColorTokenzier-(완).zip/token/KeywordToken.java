package token;

import visitor.IVisitor;

public class KeywordToken extends Token{

    public KeywordToken(String data){
        super(data);
    }

    @Override
    public String accept(IVisitor visitor) {
        return visitor.visit(this);
    }

}
