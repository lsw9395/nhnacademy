package token;

import visitor.IVisitor;

public class SymbolToken extends Token{

    public SymbolToken(String data){
        super(data);
    }

    @Override
    public String accept(IVisitor visitor) {
        return visitor.visit(this);
    }
}