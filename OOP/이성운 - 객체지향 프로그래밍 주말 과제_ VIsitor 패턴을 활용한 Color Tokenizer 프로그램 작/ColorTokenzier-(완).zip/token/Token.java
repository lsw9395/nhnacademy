package token;

import visitor.IVisitor;

public abstract class Token{
    String data;

    public Token(String data){
        this.data = data;
    }
    public String getData(){
        return data;
    }

    public abstract String accept(IVisitor visitor);
}
