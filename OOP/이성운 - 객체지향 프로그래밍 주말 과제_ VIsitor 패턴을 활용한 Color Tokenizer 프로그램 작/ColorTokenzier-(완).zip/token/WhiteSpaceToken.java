package token;

import visitor.IVisitor;

public class WhiteSpaceToken extends Token{

    public WhiteSpaceToken(String data){
        super(data);
    }

    @Override
    public String accept(IVisitor visitor) {
        return visitor.visit(this);
    }

}
