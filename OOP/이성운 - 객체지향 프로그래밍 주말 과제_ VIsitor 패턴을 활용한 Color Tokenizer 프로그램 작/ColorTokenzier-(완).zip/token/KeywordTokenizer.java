package token;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class KeywordTokenizer {
    List<String> stringLists = new ArrayList<>();
    String fileName;
    public List<Token> list = new ArrayList<>();
    static List<String> keywords = new ArrayList<>(Arrays.asList("boolean","byte","char","double","float","int","long","short","abstract","class","default","extends","implements","instanceof","interface"
    ,"break","continue","do","for","while","case","else","if","switch","final","native","new","private","protected","public","static","synchronized","threadsafe","transient","void"
    ,"catch","finally","throw","try","true","false","import","null","package","return","super","this"));
    public KeywordTokenizer(String fileName){
        this.fileName = fileName;
    }

    public void decomposition() throws IOException{
        String line = "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
        while((line=reader.readLine())!=null){
            StringTokenizer st = new StringTokenizer(line," <>(),.:/[];\"", true);
            while(st.hasMoreTokens()){
                stringLists.add(st.nextToken());
            }
        }
        reader.close();
    }

    public void check(){
        for(String k : stringLists){
            Pattern pattern = Pattern.compile("[a-zA-Zㄱ-ㅎㅏ-ㅣ가-힣0-9]{1,}");
            Matcher matcher = pattern.matcher(k);
            if(keywords.contains(k)){
                list.add(new KeywordToken(k));
            } else if(k.equals(" ")){
                list.add(new WhiteSpaceToken(k));
            } else if(matcher.find()){
                list.add(new VariableToken(k));
            } else {
                list.add(new SymbolToken(k));
            }
        }
    }
    public List<Token> getList(){
        return list;
    }



}
