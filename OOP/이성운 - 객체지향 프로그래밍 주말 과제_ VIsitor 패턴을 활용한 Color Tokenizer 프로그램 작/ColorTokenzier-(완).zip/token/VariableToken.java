package token;

import visitor.IVisitor;

public class VariableToken extends Token{

    public VariableToken(String data){
        super(data);
    }

    @Override
    public String accept(IVisitor visitor) {
        return visitor.visit(this);
    }
}
