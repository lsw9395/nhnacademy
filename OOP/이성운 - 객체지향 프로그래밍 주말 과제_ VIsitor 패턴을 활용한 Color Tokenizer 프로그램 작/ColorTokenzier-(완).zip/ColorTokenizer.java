import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import token.KeywordToken;
import token.KeywordTokenizer;
import token.SymbolToken;
import token.Token;
import token.VariableToken;
import token.WhiteSpaceToken;
import visitor.IVisitor;
import visitor.KeywordVisitor;
import visitor.SymbolVisitor;
import visitor.VariableVisitor;
import visitor.WhiteSpaceVisitor;

public class ColorTokenizer {
    public static void main(String[] args) throws IOException {
        KeywordTokenizer keywordTokenizer = new KeywordTokenizer(args[0]);
        keywordTokenizer.decomposition();
        keywordTokenizer.check();
        List<Token> list = keywordTokenizer.getList();
        IVisitor keywordVisitor = new KeywordVisitor();
        IVisitor symbolVisitor = new SymbolVisitor();
        IVisitor varialbeVisitor = new VariableVisitor();
        IVisitor whiteSpaceVisitor = new WhiteSpaceVisitor();

        try {
            String name = args[0].substring(0, args[0].lastIndexOf("."));
            File file = new File(name+".html");
            FileWriter fileWriter = new FileWriter(file);
            PrintWriter printWriter = new PrintWriter(fileWriter);
            printWriter.printf("<html>");
            printWriter.printf("<body style = \"background-color:gray\">");
            printWriter.printf("<font color=\"white\">");
            printWriter.print("<div>");
            for(Token t : list){
                if(t instanceof KeywordToken){
                    printWriter.print(t.accept(keywordVisitor));
                }
                if(t instanceof SymbolToken){
                    printWriter.print(t.accept(symbolVisitor));
                }
                if(t instanceof VariableToken){
                    printWriter.print(t.accept(varialbeVisitor));
                }
                if(t instanceof WhiteSpaceToken){
                    printWriter.print(t.accept(whiteSpaceVisitor));
                }
            }
            printWriter.printf("</font>");
            printWriter.printf("</body>");
            printWriter.printf("</html>");
            printWriter.flush();
            printWriter.close();
        } catch (Exception e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("한글도 되는지 확인입니다.");
    }
}