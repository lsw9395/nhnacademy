package org.example;

import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class URLConn {
    URL url;
    HttpURLConnection connection;
    public URLConn(String u) throws IOException {
        this.url = new URL(u);
    }
    public void setMethod(String method) throws IOException {
        this.connection = (HttpURLConnection) url.openConnection();
        connection.setDoOutput(true);
        connection.setDoInput(true);
        connection.setInstanceFollowRedirects(false);
        this.connection.setRequestMethod(method.toUpperCase());
    }

    public void setContentType(){
        this.connection.setRequestProperty("Content-Type","application/json");
    }

    public void setHeader(String property){
        String[] k = property.split(":");
        connection.setRequestProperty(k[0],k[1]);
    }
    public void requestHeader() throws IOException {
        System.out.println("요청 헤더");
        System.out.println(connection.getRequestMethod()+" "+url.getFile()+" "+url.getProtocol().toUpperCase()+"/1.1");
        System.out.println("Host: "+url.getHost());
    }

    public void respondHeader(){
        System.out.println("반응 헤더");
        Map<String, List<String>> map = connection.getHeaderFields();
        Set<String> set =map.keySet();
        for(String key:set){
            System.out.println(key + ": " + connection.getHeaderField(key));
        }
    }

    public void getJson() throws IOException {
        BufferedWriter output = new BufferedWriter(new OutputStreamWriter(System.out));
        BufferedReader input = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String line;
        StringBuilder info2 = new StringBuilder();
        while ((line = input.readLine()) != null) {
            info2.append(line);
            info2.append('\n');
        }

        JSONObject object = new JSONObject(info2.toString());
        output.write(object.toString(4));
        output.newLine();
        output.flush();
    }

    public void test(String data) throws IOException {
        OutputStream os = connection.getOutputStream();
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
        DataOutputStream writer2 = new DataOutputStream(connection.getOutputStream());
        JSONObject object = new JSONObject(data);
        //writer.write();
        //object.put("hello","world");
        writer2.writeBytes(object.toString());
        writer2.flush();
    }

    public boolean getRespond() throws IOException {
        for(int i = 0 ; i < 6 ; i++){
            int response = this.connection.getResponseCode();
            if(response == 301 || response ==302 || response == 307 || response == 308){
                String location = connection.getHeaderField("Location");
                URLConn urlConn = new URLConn(url.getProtocol()+"://"+url.getHost() + location);
                this.url = urlConn.url;
                urlConn.setMethod("get");
                this.connection = urlConn.connection;
                this.connection.setInstanceFollowRedirects(false);
                urlConn.requestHeader();
                urlConn.respondHeader();
            } else {
                return true;
            }
        }
        return false;
    }

    public void sendFile(String path) throws IOException {
        path = path.replace("@","./");
        File file = new File(path);
        connection.setRequestProperty("Content-Type", "multipart/form-data;charset=utf-8;boundary=^-----^");
        OutputStream output = connection.getOutputStream();
        PrintWriter writer = new PrintWriter(new OutputStreamWriter(output, "UTF-8"),true);
        writer.append("--" + "^-----^").append("\r\n");
        writer.append("Content-Disposition: form-data; name=\"file\"; filename=\"" + file.getName() + "\"").append("\r\n");;
        writer.append("Content-Type: " + connection.guessContentTypeFromName(file.getName())).append("\r\n");;
        writer.append("Content-Transfer-Encoding: binary").append("\r\n");
        writer.append("\r\n");
        writer.flush();

        FileInputStream inputStream = new FileInputStream(file);
        byte[] buffer = new byte[(int)file.length()];
        int bytesRead = -1;
        while ((bytesRead = inputStream.read(buffer)) != -1) {
            output.write(buffer, 0, bytesRead);
        }
        output.flush();
        inputStream.close();
        writer.append("\r\n");
        writer.flush();
        writer.append("--" + "^-----^" + "--").append("\r\n");
        writer.close();
    }
}
