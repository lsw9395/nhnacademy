package org.example;

import java.io.IOException;
import java.net.Socket;

public class ClientSocket {
    Socket socket;
    public ClientSocket(String fqdn, int port){
        try {
            this.socket = new Socket(fqdn, port);
            Sender sender = new Sender(socket);
            Receiver receiver = new Receiver(socket);
            sender.start();
            receiver.start();
            sender.join();
            receiver.join();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
