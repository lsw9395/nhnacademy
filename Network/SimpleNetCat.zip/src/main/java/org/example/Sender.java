package org.example;

import java.io.*;
import java.net.Socket;

public class Sender extends Thread{
    BufferedWriter output;
    BufferedReader console;
    Socket socket;
    public Sender(Socket socket){
        super("Sender");
        this.socket = socket;
    }

    @Override
    public void run(){
        try{
            output = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            console = new BufferedReader(new InputStreamReader(System.in));
            while(!Thread.interrupted()){
                String line = console.readLine();
                output.write(line);
                output.newLine();
                output.flush();
            }

            Runtime.getRuntime().addShutdownHook(new Thread(){
                @Override
                public void run() {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
        } catch (Exception ignore) {

        }
    }
}
