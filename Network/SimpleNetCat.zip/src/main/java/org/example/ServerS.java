package org.example;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerS {
    public ServerS(int port){
        try {
            ServerSocket server = new ServerSocket(port);
            System.out.println("연결대기중");
            Socket socket = server.accept();
            System.out.println("연결");
            Sender sender = new Sender(socket);
            Receiver receiver = new Receiver(socket);
            sender.start();
            receiver.start();
            sender.join();
            receiver.join();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}

