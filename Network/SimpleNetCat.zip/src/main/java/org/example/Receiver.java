package org.example;

import java.io.*;
import java.net.Socket;

public class Receiver extends Thread{
    BufferedReader input;
    BufferedWriter console;
    Socket socket;
    public Receiver(Socket socket){
        super("Receiver");
        this.socket = socket;
    }

    @Override
    public void run(){
        try{
            input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            console = new BufferedWriter(new OutputStreamWriter(System.out));
            while(!Thread.interrupted()){
                String line = input.readLine();
                console.write(line);
                console.newLine();
                console.flush();
            }
            Runtime.getRuntime().addShutdownHook(new Thread(){
                @Override
                public void run() {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
        } catch (Exception ignore) {

        }
    }
}
