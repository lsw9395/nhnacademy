import org.example.ServerS;

public class Test {
    public static void main(String[] args) {
        ServerS server = new ServerS(10005);
    }
}
