import org.example.ClientSocket;

public class Test2 {
    public static void main(String[] args) {
        ClientSocket clientSocket = new ClientSocket("localhost", 10005);
    }
}
