import org.apache.commons.cli.*;
import org.example.ClientSocket;
import org.example.ServerS;

public class snc {
    public static void main(String[] args) {
        Options options = new Options();
        options.addOption("h", "help", false, "display help");
        Option listen = Option.builder("l")
                            .hasArg()  
                            .argName("port")
                            .desc("listen mode")
                            .build();
        options.addOption(listen);
        
        CommandLineParser parser = new DefaultParser();
        try {
            CommandLine line = parser.parse(options, args);
            if(line.hasOption('h')){
                HelpFormatter formatter = new HelpFormatter();
                formatter.printHelp("snc", options);
            } else {
                if(line.hasOption('l')){
                    int portNumber = Integer.parseInt(line.getOptionValue('l'));
                    ServerS serverSocket = new ServerS(portNumber);
                } else {
                        int portNumber = Integer.parseInt(args[1]);
                        ClientSocket clientSocket = new ClientSocket(args[0], portNumber);
                }
            }

        } catch (ParseException e) {
            e.printStackTrace();
            System.out.println("포트 번호를 입력해주세요.");
        }


    }
}
