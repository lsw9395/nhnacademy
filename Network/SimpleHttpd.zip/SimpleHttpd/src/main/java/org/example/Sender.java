package org.example;

import java.io.*;
import java.net.Socket;

class Sender extends Thread {
    BufferedWriter output;
    DataOutputStream output2;
    BufferedReader console;
    Socket socket;
    DataInputStream bis;

    public Sender(Socket socket) {
        super("Sender");
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            output2 = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            console = new BufferedReader(new InputStreamReader(System.in));
            while (!Thread.interrupted()) {
                String line = console.readLine();
                if (line.contains("GET")) {
                    output2.writeUTF(line);
                    output2.flush();
                } else if (line.contains("POST")) {
                    String[] url = line.split(" ");
                    String fileNm = line.substring(line.lastIndexOf("/"));
                    output2.writeUTF(line);
                    output2.flush();
                    fileRead(output2, fileNm, url[1]);
                    output2.flush();
                } else if (line.contains("DELETE")) {
                    output2.writeUTF(line);
                    output2.flush();
                } else {
                    output2.writeUTF(line);
                    output2.flush();
                }
            }

        } catch (Exception ignore) {
            Thread.currentThread().interrupt();
        }
    }

    private void fileRead(DataOutputStream dos, String fileNm, String filePath) {

        try {
            dos.writeUTF(fileNm);
            System.out.println("파일 이름(" + fileNm + ")을 전송하였습니다.");


            File file = new File("."+filePath);

            bis = new DataInputStream(new BufferedInputStream(new FileInputStream(file)));
            int len;
            int size = 4096;
            byte[] data = new byte[size];
            if ((len = bis.read(data)) != -1) {
                dos.write(data, 0, len);
            }
            dos.writeUTF("");
            dos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}
