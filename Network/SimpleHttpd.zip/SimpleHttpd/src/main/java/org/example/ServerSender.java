package org.example;

import java.io.*;
import java.net.Socket;

class ServerSender extends Thread {
    BufferedWriter output;
    DataOutputStream output2;
    BufferedReader console;
    Socket socket;
    BufferedInputStream bis;

    public ServerSender(Socket socket) {
        super("Sender");
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            output2 = new DataOutputStream(socket.getOutputStream());
            console = new BufferedReader(new InputStreamReader(System.in));
            while (!Thread.interrupted()) {
                    String line = console.readLine();
                    output2.writeUTF(line);
                    output2.flush();
                }
            } catch (IOException e) {
                Thread.currentThread().interrupt();
            }
    }
}
