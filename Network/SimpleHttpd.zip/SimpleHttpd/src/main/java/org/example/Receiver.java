package org.example;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

class Receiver extends Thread {
    BufferedReader input;
    DataInputStream input2;
    BufferedWriter console;
    Socket socket;

    public Receiver(Socket socket) {
        super("Receiver");
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            input2 = new DataInputStream(socket.getInputStream());
            console = new BufferedWriter(new OutputStreamWriter(System.out));
            while (!Thread.interrupted()) {
                String line2 = input2.readUTF();
                console.write(line2);
                console.newLine();
                console.flush();
            }
        } catch (Exception ignore) {
            Thread.currentThread().interrupt();
        }
    }
}
