package org.example;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Simplehttpd {
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(Integer.parseInt(args[0]))){
            while (!Thread.interrupted()){
                System.out.println("연결 대기중입니다.");
                Socket socket = serverSocket.accept();
                System.out.println("클라이언트와 연결되었습니다.");
                ServerReceiver serverReceiver = new ServerReceiver(socket);
                ServerSender serverSender = new ServerSender(socket);
                serverSender.start();
                serverReceiver.start();
                serverSender.join();
                serverReceiver.join();
            }
        } catch (IOException e) {
            Thread.currentThread().interrupt();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}

