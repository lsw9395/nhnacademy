package org.example;

import org.json.JSONObject;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;

class ServerReceiver extends Thread {
    DataOutputStream output;
    BufferedReader input;
    DataInputStream input2;
    BufferedWriter console;
    Socket socket;

    public ServerReceiver(Socket socket) {
        super("Receiver");
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            output = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            input2 = new DataInputStream(socket.getInputStream());
            console = new BufferedWriter(new OutputStreamWriter(System.out));
            while (!Thread.interrupted()) {
                String line2 = input2.readUTF();
                if (line2.contains("GET")) {
                    if(line2.length()>5){
                        String url = line2.substring(line2.lastIndexOf("/"));
                        isFile(url);
                    }
                    else {sendHtml();output.flush();}
                } else if (line2.contains("POST")) {
                    fileWrite(input2);
                } else if (line2.contains("DELETE")) {
                    String url = line2.substring(line2.lastIndexOf("/"));
                    deleteFile(url);
                } else {
                    console.write(line2);
                    console.newLine();
                    console.flush();
                }

            }
        } catch (IOException e) {
            Thread.currentThread().interrupt();
        } finally {
            try {
                output.close();
                input2.close();
                console.close();
            } catch (Exception ignore) {}

        }
    }

    public void sendHtml() throws IOException {
        File file2 = new File("./");
        File file = new File("./index.html");
        BufferedWriter writer = new BufferedWriter(new FileWriter(file));
        File[] files = file2.listFiles();
        writer.write("<html>\n\t<Head></Head>\n\t\t<body>\n\t\t\t<h2>파일 목록</h2>\n");
        for (int i = 0; i < files.length; i++) {
            writer.write("\t\t\t\t\t<div>" + files[i].getName() + "</div>");
            writer.newLine();
        }
        writer.write("\t\t<body>\n<html>");
        writer.flush();
        writer.close();
        StringBuilder contents = new StringBuilder();
        String pageContents = "";
        try {
            File file3 = new File("./index.html");

            InputStreamReader reader = new InputStreamReader(new FileInputStream(file3), StandardCharsets.UTF_8);

            BufferedReader buff = new BufferedReader(reader);

            while ((pageContents = buff.readLine()) != null) {
                //System.out.println(pageContents);
                contents.append(pageContents);
                contents.append("\r\n");
            }

            buff.close();
            output.writeUTF(contents.toString());
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void isFile(String url) throws IOException {
        String response = "404 Not Found";
        File file = new File("./");
        File[] files = file.listFiles();
        url = url.substring(1);
        for (int i = 0; i < files.length; i++) {
            if(url.equals(files[i].getName())){
                if(url.contains(".")){
                    response = "200 OK"; break;
                }
                else {
                    response = "403 Forbidden"; break;
                }
            }
        }
        output.writeUTF(response+"\n");
        if(response.contains("200")){
            responseData(output);
        } else {
            responseHeader("./SimpleHttpd/get/get.json");
        }
        output.flush();
    }

    private void fileWrite(DataInputStream dis){
        String filePath = ".";
        try {
            System.out.println("파일 수신 작업을 시작합니다.");

            // 파일명을 전송 받고 파일명 수정
            String fileNm = dis.readUTF();


            // 파일을 생성하고 파일에 대한 출력 스트림 생성
            File file = new File(filePath + "/" + fileNm);
            String response = isFile2(fileNm);
            if(response.equals("200 OK")){
                System.out.println("파일명 " + fileNm + "을 전송받았습니다.");
                DataOutputStream bos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
                int len;
                int size = 1024;
                byte[] data = new byte[size];
                if ((len = dis.read(data)) != -1) {
                    bos.write(data,0,len);
                }
                bos.flush();
                output.writeUTF(response);
                responseData2(output);
            }
            else {
                System.out.println("파일명 " + fileNm + "을 전송 실패.");
                output.writeUTF(response);
                responseHeader(file.getPath());
                output.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public String isFile2(String url) {
        String response = "200 OK";
        File file = new File("./");
        File[] files = file.listFiles();
        url = url.substring(1);
        for (int i = 0; i < files.length; i++) {
            if(url.equals(files[i].getName())){
                if(url.contains(".")){
                    response = "409 Conflict"; break;
                }
                else {
                    response = "403 Forbidden"; break;
                }
            }
        }
        return response;
    }
    public void responseData(DataOutputStream output) throws IOException {
        String url ="./SimpleHttpd/get/get.json";
        responseHeader(url);
        BufferedReader jsonReader = new BufferedReader(new InputStreamReader(new FileInputStream(url)));
        String line;
        StringBuilder info2 = new StringBuilder();
        while((line= jsonReader.readLine())!= null){
            info2.append(line);
            info2.append('\n');
        }
        output.writeUTF(info2.toString());
        output.flush();
    }
    public void responseData2(DataOutputStream output) throws IOException {
        String url ="./SimpleHttpd/post/post.json";
        responseHeader(url);
        BufferedReader jsonReader = new BufferedReader(new InputStreamReader(new FileInputStream(url)));
        String line;
        StringBuilder info2 = new StringBuilder();
        while((line= jsonReader.readLine())!= null){
            info2.append(line);
            info2.append('\n');
        }
        File file = new File("./");
        File[] files = file.listFiles();
        ArrayList list = new ArrayList();
        for(File f:files){
            list.add(f.getName());
        }
        JSONObject object = new JSONObject(info2.toString());
        JSONObject object1 = new JSONObject(object.get("headers").toString());
        object1.put("content-type","multipart/form-data");
        object.put("headers",object1);
        object.put("files",list);
        output.writeUTF(object.toString(4));
        output.flush();
    }

    public void responseHeader(String url) throws IOException {
        File file = new File(url);
        StringBuilder info = new StringBuilder();
        info.append("Date: "+new Date()+"\n");
        info.append("Content-Type: application/"+file.getName().substring(file.getName().lastIndexOf('.')+1)+"\n");
        info.append("Content-length: "+ file.length()+"\n\n");
        output.writeUTF(info.toString());
    }

    public void deleteFile(String url) throws IOException {
        String response = "204 No Content";
        File file = new File("./");
        File[] files = file.listFiles();
        url = url.substring(1);
        for (int i = 0; i < files.length; i++) {
            if(url.equals(files[i].getName())){
                if(url.contains(".")) {
                    response = "204 No Content";
                    File file1 = new File("./" + url);
                    System.out.println(file1.getName());
                    if(file1.delete()){
                        System.out.println("삭제 완");
                    }
                }
                else {
                    response = "403 Forbidden"; break;
                }
            }
        }
        output.writeUTF(response+"\n");
        if(response.equals("204 No Contetn")){
            responseData2(output);
        }
        output.flush();
    }
}
