package org.example;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
    public static void main(String[] args) {
        try (Socket socket = new Socket(args[0], Integer.parseInt(args[1]))){
            while(!Thread.interrupted()){
                Sender sender =new Sender(socket);
                Receiver receiver = new Receiver(socket);
                sender.start();
                receiver.start();
                sender.join();
                receiver.join();
            }
        } catch (IOException | InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

