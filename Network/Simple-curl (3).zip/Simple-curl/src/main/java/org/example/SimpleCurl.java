package org.example;

import org.apache.commons.cli.*;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.http.HttpClient;

public class SimpleCurl {
    public static void main(String[] args) {
        Options options = new Options();

        options.addOption("v", "verbose, 요청, 응답 헤더를 출력합니다.");
        options.addOption("L","서버의 응답이 30x 계열이면 다음 응답을 따라 갑니다.");
        Option optionH = Option.builder("H")
                .hasArg()
                .argName("line")
                .desc("임의 헤더를 서버로 전송합니다.")
                .build();
        Option optionD = Option.builder("d")
                .hasArg()
                .argName("data")
                .desc("POST, PUT 등에 데이터를 전송합니다.")
                .build();
        Option optionX = Option.builder("X")
                .hasArg()
                .argName("command")
                .desc("사용할 method를 지정합니다. 지정되지 않은 경우 기본값을 GET입니다.")
                .build();
        Option name = Option.builder("F")
                .hasArgs()
                .valueSeparator('=')
                .desc("multipart/form-data 를 구성하여 전송합니다. content 부분 @filename을 사용할 수 있습니다.")
                .build();
        options.addOption(optionX);
        options.addOption(optionD);
        options.addOption(optionH);
        options.addOption(name);
        try{
            CommandLineParser parser = new DefaultParser();
            CommandLine lines = parser.parse(options,args);
            if(args.length < 1){
                HelpFormatter formatter = new HelpFormatter();
                formatter.printHelp("scurl [options] url",options);
                return;
            }
            URLConn urlConn = new URLConn(args[args.length-1]);
            urlConn.setMethod("get");
            if(args.length==1){
                urlConn.getJson();
                return;
            }
            for(Option option : lines.getOptions()){
                if(option.getOpt()=="X"){
                    switch (option.getValue()){
                        case "POST": urlConn.setMethod("post"); break;
                        case "PUT": urlConn.setMethod("put");break;
                        case "DELETE" : urlConn.setMethod("delete");break;
                        default: break;
                    }
                }
                if(option.getOpt()=="H"){
                    if(option.getValue().contains("Content-Type")){
                        urlConn.setContentType();
                    } else {
                        urlConn.setHeader(option.getValue());
                    }
                }
                if(option.getOpt()=="L"){
                    if(!urlConn.getRespond()){
                        System.out.println("Error");
                        return;
                    } else {
                        urlConn.getJson();
                        return;
                    }
                }
                if(option.getOpt()=="F"){
                    urlConn.setMethod("post");
                    urlConn.sendFile(option.getValuesList().get(1));
                }
            }
            if(lines.hasOption("d")){
                urlConn.test(lines.getOptionValue("d"));
            }
            if(lines.hasOption("v")){
                urlConn.requestHeader();
                urlConn.respondHeader();
            }
            urlConn.getJson();
        } catch (ParseException e) {
            HelpFormatter formatter = new HelpFormatter();
            formatter.printHelp("scurl [options] url",options);
        } catch (IOException e) {
            HelpFormatter formatter = new HelpFormatter();
            formatter.printHelp("scurl [options] url",options);
        }
    }
}
