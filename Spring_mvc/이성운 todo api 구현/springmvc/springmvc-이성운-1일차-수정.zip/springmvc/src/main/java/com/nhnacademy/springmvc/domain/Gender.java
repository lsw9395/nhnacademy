package com.nhnacademy.springmvc.domain;

public enum Gender {
    M,F
}
