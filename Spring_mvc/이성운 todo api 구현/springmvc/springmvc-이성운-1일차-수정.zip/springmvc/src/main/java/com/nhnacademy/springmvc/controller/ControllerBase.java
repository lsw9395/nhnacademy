package com.nhnacademy.springmvc.controller;

public interface ControllerBase {
}
