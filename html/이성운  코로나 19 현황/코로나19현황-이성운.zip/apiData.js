const apiData = function(){
    'use strict';
    const SERVICE_KEY = "tQn0NDg%2BdMrnHVl1bTge6I0LsySzOaMGNmbEEwbXRnzHE32NgsdTKxB4nvugQDPHlxzP0gI08KJF90qSAJlfjQ%3D%3D";
    const api = new Object();

    api.covidAccumulate = async function(covidDate){
        let url = "http://apis.data.go.kr/1352000/ODMS_COVID_02/callCovid02Api";
        let queryParams = '?' + encodeURIComponent('serviceKey') + '=' + SERVICE_KEY; /*Service Key*/
        queryParams += '&' + encodeURIComponent('pageNo') + '=' + encodeURIComponent('1'); /**/
        queryParams += '&' + encodeURIComponent('numOfRows') + '=' + encodeURIComponent('500'); /**/
        queryParams += '&' + encodeURIComponent('apiType') + '=' + encodeURIComponent('JSON'); /**/
        queryParams += '&' + encodeURIComponent('status_dt') + '=' + covidDate; /**/
        url +=queryParams;
        console.log(url);
        const response = await fetch(url);
        if(!response.ok){
            throw new Error("데이터를 찾을 수 없습니다.");
        }
        const json = await response.json();
        return json;
    }
    api.covidToday = async function(covidDate){
        let url = "http://apis.data.go.kr/1790387/covid19CurrentStatusKorea/covid19CurrentStatusKoreaJason?serviceKey="+SERVICE_KEY+"&";
        console.log(url);

        const response = await fetch(url);
        if(!response.ok){
            throw new Error("데이터를 찾을 수 없습니다.");
        }
        const json = await response.json();
        return json.response.result[0];
    }
    api.covidGender = async function(year,month,day){
        let url = "http://apis.data.go.kr/1352000/ODMS_COVID_05/callCovid05Api";
        let queryParams = '?' + encodeURIComponent('serviceKey') + '=' + SERVICE_KEY; /*Service Key*/
        queryParams += '&' + encodeURIComponent('pageNo') + '=' + encodeURIComponent('1'); /**/
        queryParams += '&' + encodeURIComponent('numOfRows') + '=' + encodeURIComponent('500'); /**/
        queryParams += '&' + encodeURIComponent('apiType') + '=' + encodeURIComponent('JSON'); /**/
        queryParams += '&' + encodeURIComponent('create_dt') + '=' + year+"-"+month+"-"+day; /**/

        url += queryParams;

        const response = await fetch(url);
        if(!response.ok){
            throw new Error("데이터를 찾을 수 없습니다.");
        }
        const json = await response.json();
        return json.items;
    }


    return api;
};