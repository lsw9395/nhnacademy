'user strict';
const navi = new Navigator("btn-prev","btn-next","btn-current");
const store = apiData();
console.log("year:" + navi.getYear());
console.log("month:" + navi.getMonth());
console.log("month:" + navi.getDay());

(function(){
    'use strict';

    window.addEventListener("DOMContentLoaded",async (event)=>{
        const loading = document.getElementById("loading_table");
        displayYearMonth(navi.getYear(), navi.getMonth(), navi.getDay());
        const covidDate = navi.getYear()+navi.getMonth()+navi.getDay();
        await displayTable(navi.getYear(), navi.getMonth(), navi.getDay());
        await displayCovid(covidDate);
        loading.setAttribute("style","display: none;");
    });

    function displayYearMonth(targetYear, targetMonth, targetDay){
        // html element : todo-nav-year 표시
        const todoNavYear = document.getElementById("nav-year");
        todoNavYear.innerText = targetYear
        // html element : todo-nav-month 표시
        const todoNavMonth = document.getElementById("nav-month");
        todoNavMonth.innerText = targetMonth;

        const todoNavDay = document.getElementById("nav-day");
        todoNavDay.innerText = targetDay;
    }
    async function displayCovid(covidDate){
        try {
            const intl = new Intl.NumberFormat();
            const data1 = await store.covidAccumulate(covidDate);
            const covidCalDie = document.getElementById("covid_cal_die");
            covidCalDie.innerText = intl.format(data1.items[0].gPntCnt)+"명";
            const covidCalNum = document.getElementById("covid_cal_num");
            covidCalNum.innerText = intl.format(data1.items[0].hPntCnt)+"명";
            const covidCalChk = document.getElementById("covid_cal_chk");
            covidCalChk.innerText = intl.format(data1.items[0].accExamCnt)+"회";
            const covidCalPercent = document.getElementById("covid_cal_percent");
            const data2= await store.covidToday();
            covidCalPercent.innerText = data2.rate_deaths;
            const covidTodayNum = document.getElementById("covid_today_num");
            covidTodayNum.innerText = data2.cnt_confirmations;
            const covidTodayDie = document.getElementById("covid_today_die");
            covidTodayDie.innerText = data2.cnt_deaths;
            const covidTodayChk = document.getElementById("covid_today_chk");
            covidTodayChk.innerText = data2.cnt_hospitalizations;
            const covidTodayPercent = document.getElementById("covid_today_percent");
            covidTodayPercent.innerText = data2.cnt_severe_symptoms;
        } catch (error) {
            alert(error.message);
        }

    }
    async function displayTable(year, month, day){
        const table = document.getElementById("age_list");
        const tbody = table.getElementsByTagName("tbody")[0];
        const data3 = await store.covidGender(year,month,day);
        const test = data3.sort(function(a,b){
            let x = a.gubun.toLowerCase();
            let y = b.gubun.toLowerCase();
            if(x < y){
                return -1;
            }
            if(x > y){
                return 1;
            }
            return 0;
        });
        const maxValues = {
                criticalRate: Math.max(...data3.filter(item => item.gubun !== '여성' && item.gubun !== '남성').map(item => parseFloat(item.criticalRate))),
                death: Math.max(...data3.filter(item => item.gubun !== '여성' && item.gubun !== '남성').map(item => parseInt(item.death))),
                confCase: Math.max(...data3.filter(item => item.gubun !== '여성' && item.gubun !== '남성').map(item => parseInt(item.confCase))),
                deathRate: Math.max(...data3.filter(item => item.gubun !== '여성' && item.gubun !== '남성').map(item => parseFloat(item.deathRate))),
                confCaseRate: Math.max(...data3.filter(item => item.gubun !== '여성' && item.gubun !== '남성').map(item => parseFloat(item.confCaseRate))),
            };
        const intl = new Intl.NumberFormat();
        for(const item of test){
            const tr = document.createElement("tr");
            const td1 = document.createElement("td");
            const td2 = document.createElement("td");
            const td3 = document.createElement("td");
            const td4 = document.createElement("td");
            const td5 = document.createElement("td");
            const td6 = document.createElement("td");
            td1.innerText = item.gubun;
            td2.innerText = item.criticalRate;
            console.log(maxValues.criticalRate);
            if(parseFloat(item.criticalRate)===maxValues.criticalRate){
                td2.setAttribute("style","background-color: yellow;");
            }
            td3.innerText = item.death;
            if(parseInt(item.death)===maxValues.death){
                td3.setAttribute("style","background-color: yellow;");
            }
            td4.innerText = intl.format(item.confCase);
            if(parseInt(item.confCase)===maxValues.confCase){
                td4.setAttribute("style","background-color: yellow;");
            }
            td5.innerText = intl.format(item.deathRate);
            if(parseFloat(item.deathRate)===maxValues.deathRate){
                td5.setAttribute("style","background-color: yellow;");
            }
            td6.innerText = item.confCaseRate;
            if(parseFloat(item.confCaseRate)===maxValues.confCaseRate){
                td6.setAttribute("style","background-color: yellow;");
            }
            tr.append(td1,td2,td3,td4,td5,td6);
            tbody.append(tr);
        }
    }
})();