function Navigator(uiBtnPrevMonthId, uiBtnNextMonthId, uiBtnCurrentMonthId){

    let year = null;
    let month = null;
    let day = null;

    this.uiBtnPrevMonthId = uiBtnPrevMonthId;
    this.uiBtnNextMonthId = uiBtnNextMonthId;
    this.uiBtnCurrentMonthId = uiBtnCurrentMonthId;

    (function(){
        const searchParam = new URLSearchParams(document.location.search);
        year = searchParam.get("year");
        month = searchParam.get("month");
        day = searchParam.get("day");
        const today = new Date();

    if(year == null){
        year = today.getFullYear();
    }

    if(month == null){
        month = today.getMonth() + 1;
        month = _convertToZeroMonthAndDay(month);
    }
    if(day == null){
        day = today.getDate();
        day = _convertToZeroMonthAndDay(day);
    }
    })();





    window.addEventListener("DOMContentLoaded",function(){

        let btnPrevMonth = document.getElementById(uiBtnPrevMonthId);
        let btnNextMonth = document.getElementById(uiBtnNextMonthId);
        let btnCurrentMonth = document.getElementById(uiBtnCurrentMonthId);

        https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/Error
        if(btnPrevMonth == null){
            throw new Error("not find btnPrevMonth");
        }
        if(btnNextMonth == null){
            throw new Error("not find btnNextMonth");
        }
        if(btnCurrentMonth == null){
            throw new Error("not find btnCurrentMonth");
        }

        //버튼 이벤트 등록
        //이전
        btnPrevMonth.addEventListener("click",function(){
            if(day == 1 && month==1){
                month = 12;
                year = parseInt(year) -1;
                day = new Date(year, parseInt(month),0).getDate();
            } else if(day==1){
                month = parseInt(month) -1;
                day = new Date(year, parseInt(month),0).getDate();
            } else {
                day = parseInt(day) - 1;
            }
            _navigate(year, month, day);
        });

        //다음
        btnNextMonth.addEventListener("click",function(){
            let targetYear = year;
            let targetMonth = month;
            let targetDay = day;
            if(targetDay==(new Date(targetYear, parseInt(targetMonth),0).getDate()) && targetMonth==12){
                targetMonth = 1;
                targetYear = parseInt(targetYear) + 1;
                targetDay = 1;
            } else if(targetDay==(new Date(targetYear, parseInt(targetMonth),0).getDate())){
                targetMonth = parseInt(targetMonth) + 1;
                targetDay = 1;
            } else {
                targetDay = parseInt(targetDay) + 1;
            }
            const today = new Date();
            let nextday = new Date(targetYear+"-"+targetMonth+"-"+targetDay);
            if(today < nextday){
                alert("다음 코로나 현황이 존재하지 않습니다.");
                return ;
            }
            year = targetYear;
            month = targetMonth;
            day = targetDay;
            _navigate(year, month, day);
        });
        //오늘
        btnCurrentMonth.addEventListener("click",function(){
            const today = new Date();
            year = today.getFullYear();
            month = today.getMonth()+1;
            day = today.getDate();
            _navigate(year,month,day);
        });
    });


    function _navigate(targetYear,targetMonth, targetDay){
        targetYear = _convertToZeroMonthAndDay(targetYear);
        targetMonth = _convertToZeroMonthAndDay(targetMonth);
        targetDay = _convertToZeroMonthAndDay(targetDay);
        location.href = "./index.html?year="+targetYear+"&month="+targetMonth+"&day="+targetDay;
    }
    function _convertToZeroMonthAndDay(d){
        d = parseInt(d);
        if(d<10){
            d = "0"+d;
        }
        return d;
    }

    return {
        getYear : function(){
            return year;
        },
        getMonth : function(){
            return month;
        },
        getDay : function(){
            return day;
        },
        convertToZeroMonthAndDay : function(d){
            return _convertToZeroMonthAndDay(d);
        }
    }

}