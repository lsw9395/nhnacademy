const apiData = function(){
    'use strict';
    const SERVICE_KEY = "tQn0NDg%2BdMrnHVl1bTge6I0LsySzOaMGNmbEEwbXRnzHE32NgsdTKxB4nvugQDPHlxzP0gI08KJF90qSAJlfjQ%3D%3D";
    const api = new Object();

    api.covidAccumulate = async function(covidDate){
        let url = "http://apis.data.go.kr/1352000/ODMS_COVID_02/callCovid02Api";
        let queryParams = '?' + encodeURIComponent('serviceKey') + '=' + SERVICE_KEY; /*Service Key*/
        queryParams += '&' + encodeURIComponent('pageNo') + '=' + encodeURIComponent('1'); /**/
        queryParams += '&' + encodeURIComponent('numOfRows') + '=' + encodeURIComponent('500'); /**/
        queryParams += '&' + encodeURIComponent('apiType') + '=' + encodeURIComponent('JSON'); /**/
        queryParams += '&' + encodeURIComponent('status_dt') + '=' + covidDate; /**/
        url +=queryParams;
        const response = await fetch(url);
        if(!response.ok){
            throw new Error("데이터를 찾을 수 없습니다.");
        }
        const json = await response.json();
        if((json.items[0] == null || json.items[0] == undefined)){
            throw new Error("누적 데이터가 업로드 되지 않았습니다.")
        }
        console.log("총괄:"+json.items);
        return json;
    }
    api.covidToday = async function(covidDate){
        let url = "http://apis.data.go.kr/1790387/covid19CurrentStatusKorea/covid19CurrentStatusKoreaJason?serviceKey="+SERVICE_KEY+"&";
        console.log(url);

        const response = await fetch(url);
        if(!response.ok){
            throw new Error("데이터를 찾을 수 없습니다.");
        }
        const json = await response.json();
        if((json.response.result[0] == null || json.response.result[0] == undefined)){
            throw new Error("일일 데이터가 업로드 되지 않았습니다.")
        }
        console.log("일일"+json);
        return json.response.result[0];
    }
    api.covidGender = async function(year,month,day){
        let url = "http://apis.data.go.kr/1352000/ODMS_COVID_05/callCovid05Api";
        let queryParams = '?' + encodeURIComponent('serviceKey') + '=' + SERVICE_KEY; /*Service Key*/
        queryParams += '&' + encodeURIComponent('pageNo') + '=' + encodeURIComponent('1'); /**/
        queryParams += '&' + encodeURIComponent('numOfRows') + '=' + encodeURIComponent('500'); /**/
        queryParams += '&' + encodeURIComponent('apiType') + '=' + encodeURIComponent('JSON'); /**/
        queryParams += '&' + encodeURIComponent('create_dt') + '=' + year+"-"+month+"-"+day; /**/

        url += queryParams;

        const response = await fetch(url);
        if(!response.ok){
            throw new Error("데이터를 찾을 수 없습니다.");
        }
        const json = await response.json();
        if((json.items[0] == null || json.items[0] == undefined)){
            throw new Error("성별 데이터가 업로드 되지 않았습니다.")
        }
        console.log("성별"+json);
        return json.items;
    }


    return api;
};